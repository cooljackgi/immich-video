#!/bin/bash

set -e

echo "🧠 Starte Setup für Ollama & blip-caption..."

# 1. Ollama installieren
if ! command -v ollama &> /dev/null; then
  echo "📦 Ollama wird installiert..."
  curl -fsSL https://ollama.com/install.sh | sh
else
  echo "✅ Ollama ist bereits installiert."
fi

# 2. Ollama starten
echo "🚀 Starte Ollama..."
pkill ollama || true
nohup ollama serve > /dev/null 2>&1 &

# 3. blip-caption Image bauen
if ! docker images | grep -q "blip-caption"; then
  echo "🔧 Baue blip-caption Docker-Image..."
  docker build -t blip-caption:latest ./blip-caption
else
  echo "✅ blip-caption Image ist bereits vorhanden."
fi

# 4. blip-caption Container starten
if docker ps -a | grep -q "blip-caption"; then
  echo "🔁 Starte vorhandenen blip-caption Container..."
  docker start blip-caption
else
  echo "🚀 Starte neuen blip-caption Container..."
  docker run -d --name blip-caption -p 5000:5000 blip-caption:latest
fi

echo ""
echo "✅ Setup abgeschlossen!"
echo "🌐 Ollama API:     http://localhost:11434"
echo "🖼️  BLIP Caption:  http://localhost:5000/caption"
